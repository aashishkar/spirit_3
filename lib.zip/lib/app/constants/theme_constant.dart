import 'package:flutter/material.dart';

class ThemeConstant {
  ThemeConstant._();
  static const Color primaryColor = Color(0xFFFE5404);
  static const Color appBarColor = Color(0xFFFE5404);
}
